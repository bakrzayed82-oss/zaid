package com.bakr.quranlisten

import android.app.Activity
import android.app.DownloadManager
import android.content.*
import android.database.Cursor
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.content.FileProvider
import java.io.*
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private data class Reader(val id: String, val name: String, val details: String, val zipUrl: String, val sourceUrl: String)
    private val readers = listOf(
        Reader(
            "shahat",
            "الشيخ الشحات محمد أنور",
            "466 تلاوة مجوّدة مختارة • حجم التنزيل نحو 3 جيجابايت",
            "https://archive.org/compress/shohatanwarm3raj/formats%3DVBR%20MP3%26file%3D/shohatanwarm3raj.zip",
            "https://archive.org/details/shohatanwarm3raj"
        ),
        Reader(
            "mamdooh",
            "الشيخ ممدوح عامر",
            "15 تلاوة وحفلة مجوّدة مختارة • حجم التنزيل نحو 253 ميجابايت",
            "https://archive.org/compress/mp3---quran----telawat--by---mamdoo7----3amer/formats%3DVBR%20MP3%26file%3D/mp3---quran----telawat--by---mamdoo7----3amer.zip",
            "https://archive.org/details/mp3---quran----telawat--by---mamdoo7----3amer"
        )
    )

    private lateinit var root: LinearLayout
    private lateinit var statusText: TextView
    private var player: MediaPlayer? = null
    private var currentDownloadId: Long = -1L
    private var currentReaderId: String? = null

    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
            val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            if (id != currentDownloadId) return
            val manager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            val query = DownloadManager.Query().setFilterById(id)
            manager.query(query).use { cursor ->
                if (cursor != null && cursor.moveToFirst()) {
                    val status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                    if (status == DownloadManager.STATUS_SUCCESSFUL) {
                        val readerId = currentReaderId ?: return
                        val file = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "$readerId.zip")
                        statusText.text = "اكتمل التنزيل. جارٍ تجهيز التلاوات المجوّدة..."
                        Thread {
                            try {
                                val target = File(filesDir, "audio/$readerId")
                                target.mkdirs()
                                unzip(file, target)
                                file.delete() // Keep only the extracted audio; avoid storing ZIP and MP3 copies together.
                                getSharedPreferences("downloads", MODE_PRIVATE).edit().putBoolean(readerId, true).apply()
                                runOnUiThread {
                                    statusText.text = "تم حفظ التلاوات المجوّدة على الهاتف. يمكنك الاستماع بدون إنترنت."
                                    showAudioFiles(readerId)
                                }
                            } catch (e: Exception) {
                                runOnUiThread { statusText.text = "تعذر فك ملفات الصوت: ${e.localizedMessage}" }
                            }
                        }.start()
                    } else {
                        statusText.text = "فشل تنزيل الملف. تحقق من الإنترنت وحاول مرة أخرى."
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerReceiver(downloadReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(downloadReceiver, filter)
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(downloadReceiver) } catch (_: Exception) {}
        player?.release(); player = null
        super.onDestroy()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 24, 20, 28); setBackgroundColor(0xFFF7F5EF.toInt()) }
        scroll.addView(root)
        setContentView(scroll)

        val header = TextView(this).apply {
            text = "القرآن الكريم\nاستماع فقط • تلاوات مجوّدة"
            textSize = 25f; gravity = Gravity.CENTER; setTextColor(0xFFF4D58A.toInt())
            setPadding(18, 30, 18, 30); setBackgroundColor(0xFF102C25.toInt())
        }
        root.addView(header, matchWrap())
        val intro = TextView(this).apply {
            text = "استمع إلى التلاوات المجوّدة فقط دون عرض المصحف أو نص الآيات. اختر القارئ ونزّل مجموعته مرة واحدة؛ وبعد حفظ الملفات يمكنك الاستماع دون إنترنت. هذه مجموعات تلاوات مختارة وليست ختمة كاملة من 114 سورة."
            textSize = 16f; setTextColor(0xFF263A33.toInt()); setPadding(4, 18, 4, 18)
        }
        root.addView(intro)

        readers.forEach { reader ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            val title = TextView(this).apply { text = reader.name; textSize = 20f; setTextColor(0xFF153B30.toInt()) }
            card.addView(title)
            val details = TextView(this).apply {
                text = reader.details
                textSize = 14f
                setTextColor(0xFF5C665F.toInt())
                setPadding(0, 6, 0, 8)
            }
            card.addView(details)
            val download = Button(this).apply {
                text = if (isExtracted(reader.id)) "التلاوات محفوظة - استمع الآن" else "تنزيل التلاوات المجوّدة مرة واحدة"
                setOnClickListener { if (isExtracted(reader.id)) showAudioFiles(reader.id) else downloadReader(reader) }
            }
            card.addView(download, matchWrap())
            val source = TextView(this).apply {
                text = "صفحة المصدر والتفاصيل"
                textSize = 14f; setTextColor(0xFF456B5D.toInt()); setPadding(0, 8, 0, 0)
                setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(reader.sourceUrl))) }
            }
            card.addView(source)
            val params = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 16 }
            root.addView(card, params)
        }

        val share = Button(this).apply {
            text = "مشاركة تطبيق APK"
            setOnClickListener { shareInstalledApk() }
        }
        root.addView(share, matchWrap())
        statusText = TextView(this).apply { text = "جاهز"; textSize = 14f; setTextColor(0xFF37564B.toInt()); setPadding(4, 16, 4, 12) }
        root.addView(statusText)
    }

    private fun downloadReader(reader: Reader) {
        if (isExtracted(reader.id)) { showAudioFiles(reader.id); return }
        val downloads = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        val destDir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
        destDir.mkdirs()
        val archive = File(destDir, "${reader.id}.zip")
        if (archive.exists() && archive.length() > 0) {
            statusText.text = "الملف موجود. جارٍ فك الضغط..."
            Thread {
                try {
                    val target = File(filesDir, "audio/${reader.id}"); target.mkdirs(); unzip(archive, target)
                    archive.delete() // Keep only the extracted audio after a successful extraction.
                    getSharedPreferences("downloads", MODE_PRIVATE).edit().putBoolean(reader.id, true).apply()
                    runOnUiThread { statusText.text = "تم تجهيز التلاوات المجوّدة دون إنترنت."; showAudioFiles(reader.id) }
                } catch (e: Exception) { runOnUiThread { statusText.text = "تعذر تجهيز الملفات: ${e.localizedMessage}" } }
            }.start()
            return
        }
        try {
            val request = DownloadManager.Request(Uri.parse(reader.zipUrl))
                .setTitle("تنزيل ${reader.name}")
                .setDescription("سيتم حفظ التلاوات على الهاتف للاستماع دون إنترنت")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
                .setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, "${reader.id}.zip")
            currentReaderId = reader.id
            currentDownloadId = downloads.enqueue(request)
            statusText.text = "بدأ تنزيل مجموعة التلاوات المجوّدة للشيخ ${reader.name}. سيظهر إشعار عند اكتمالها."
        } catch (e: Exception) {
            statusText.text = "تعذر بدء التنزيل: ${e.localizedMessage}"
        }
    }

    private fun isExtracted(id: String): Boolean {
        val folder = File(filesDir, "audio/$id")
        return getSharedPreferences("downloads", MODE_PRIVATE).getBoolean(id, false) && folder.walkTopDown().any { it.isFile && it.extension.equals("mp3", true) }
    }

    private fun unzip(zipFile: File, destination: File) {
        ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zis ->
            var entry = zis.nextEntry
            val base = destination.canonicalPath + File.separator
            while (entry != null) {
                val out = File(destination, entry.name)
                val canonical = out.canonicalPath
                if (!canonical.startsWith(base)) throw IOException("Invalid archive path")
                if (entry.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    BufferedOutputStream(FileOutputStream(out)).use { output -> zis.copyTo(output) }
                }
                zis.closeEntry(); entry = zis.nextEntry
            }
        }
    }

    private fun showAudioFiles(readerId: String) {
        val folder = File(filesDir, "audio/$readerId")
        val files = folder.walkTopDown().filter { it.isFile && it.extension.lowercase() in listOf("mp3", "m4a", "ogg") }.sortedBy { it.name }.toList()
        root.findViewWithTag<View>("audio_section")?.let { root.removeView(it) }
        val section = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "audio_section"; setPadding(0, 10, 0, 10) }
        section.addView(TextView(this).apply { text = "التلاوات المجوّدة المحفوظة (${files.size})"; textSize = 19f; setTextColor(0xFF153B30.toInt()) })
        if (files.isEmpty()) section.addView(TextView(this).apply { text = "لم يتم العثور على ملفات صوت داخل الحزمة."; setTextColor(0xFF8B3A32.toInt()) })
        files.forEach { file ->
            val button = Button(this).apply {
                text = "▶  ${file.nameWithoutExtension}"
                setOnClickListener { playFile(file) }
            }
            section.addView(button, matchWrap())
        }
        root.addView(section)
        statusText.text = "التلاوات المجوّدة محفوظة على الجهاز؛ لا تحتاج إنترنت لتشغيلها."
    }

    private fun playFile(file: File) {
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                setOnPreparedListener { it.start(); statusText.text = "يعمل الآن: ${file.nameWithoutExtension}" }
                setOnCompletionListener { statusText.text = "انتهت التلاوة." }
                setOnErrorListener { _, _, _ -> statusText.text = "تعذر تشغيل هذا الملف الصوتي."; true }
                prepareAsync()
            }
        } catch (e: Exception) { statusText.text = "خطأ في تشغيل الصوت: ${e.localizedMessage}" }
    }

    private fun shareInstalledApk() {
        try {
            val source = File(applicationInfo.sourceDir)
            val shareDir = File(cacheDir, "shared").apply { mkdirs() }
            val apk = File(shareDir, "QuranListening.apk")
            source.inputStream().use { input -> apk.outputStream().use { output -> input.copyTo(output) } }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", apk)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "تطبيق القرآن الكريم - استماع")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "مشاركة تطبيق القرآن الكريم"))
        } catch (e: Exception) { statusText.text = "تعذرت مشاركة APK: ${e.localizedMessage}" }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
}
